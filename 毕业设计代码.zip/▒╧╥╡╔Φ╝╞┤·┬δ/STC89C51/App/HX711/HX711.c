#include "HX711.h"
#include "lcd12864.h"
#include "public.h"

long Weight_Shiwu = 0;
long HX711_Data = 0;
u8 caculate_time=0;
u32 Weight_Maopi = 0;
u16 ge=0,shi=0,bai=0,qian=0;time_ge=0;time_shi=0;
u8 w[4]="0000";//��������
u8 time[3]="00";//ʵʱʣ��ʱ��

u32 ReadCount(void)
{
	u32 Count;
	u8 i;
	ADSK=0;
	Count=0;
	while(ADDO);
	for(i=0;i<24;i++)
		{
			ADSK=1;
			Count=Count<<1;
			ADSK=0;
			if(ADDO) Count++;
		}
		ADSK=1;
		Count=Count^0x800000;
		ADSK=0;
		return(Count);
}
void Get_Maopi()
{
	Weight_Maopi = ReadCount();	
} 

void Get_Weight()
	{
		Weight_Shiwu = ReadCount();
	Weight_Shiwu = Weight_Shiwu - Weight_Maopi;		//��ȡ����
	if(Weight_Shiwu > 0)			
	{	
	Weight_Shiwu = (unsigned int)((float)Weight_Shiwu/GapValue); 	//����ʵ���ʵ������	
   
//д��λ
		ge=Weight_Shiwu%10; 
		w[3]='0'+ge;
//дʮλ 
		shi=Weight_Shiwu/10%10; 
		w[2]='0'+shi;
//д��λ
		bai=Weight_Shiwu/100%10;
		w[1]='0'+bai;
//дǧλ
		qian=Weight_Shiwu/1000; 
		w[0]='0'+qian;
		caculate_time=(Weight_Shiwu/25);
		if(caculate_time>90)
			caculate_time=90;
		else if(caculate_time<20)
			caculate_time=20;
		time_shi=caculate_time/10;

		time[0]='0'+time_shi;
		time_ge=caculate_time%10;
		time[1]='0'+time_ge;
		time[2]='\0';
		lcd12864_show_string(5,2,w);
		lcd12864_show_string(6,3,time);
		HX711_Data=(Weight_Shiwu/25);
		
	}
	}
	
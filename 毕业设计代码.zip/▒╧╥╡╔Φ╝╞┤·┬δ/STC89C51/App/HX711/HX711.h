#ifndef _HX711_H
#define _HX711_H

#include "public.h"
#include "lcd12864.h"
#define GapValue 400
sbit ADDO = P2^0;
sbit ADSK = P2^1;



void Get_Maopi();
void lcd12864_show_string(u8 x,u8 y,u8 *str);
void Get_Weight();

#endif
#ifndef _ULN2003_H
#define _ULN2003_H
#include "public.h"
#include "time.h"

sbit IN1_A=P1^0;
sbit IN2_B=P1^1;
sbit IN3_C=P1^2;
sbit IN4_D=P1^3;

extern u8 Speed;

void time1_init(void);
void time1_start(void);
void time1_stop(void);



#endif
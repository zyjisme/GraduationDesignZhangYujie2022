// index.js
// 获取应用实例
import Toast from "../../@vant/weapp/toast/toast";
//import Toast from 'path/to/@vant/weapp/dist/toast/toast';
import {
  connect
} from "../../utils/mqttjs3/mqtt";

/******************* 可能需要你修改的部分 ******************/
const mqttHost = "************************"; //mqtt 服务器域名/IP
const mqttPort = 8084; //mqtt 服务器域名/IP



const deviceSubTopic = "/zhangyujiewashingPub"; //  设备订阅topic（小程序发布命令topic）
const devicePubTopic = "/zhangyujiewashingSub"; //  设备发布topic（小程序订阅数据topic）

/********************* 一般不用动这些 ********************/

const mpSubTopic = devicePubTopic;
const mpPubTopic = deviceSubTopic;

const mqttUrl = `wxs://${mqttHost}:${mqttPort}/mqtt`; //  mqtt连接路径
let dataFromTime = "";

Page({
  data: {
    client: {},
    NoticeBar:false,//通知栏默认不显示
    ButtonAllow:false,//按钮可以点击
    NoticeBarWarning:false,//故障警告默认不显示
    RunningSt:"空闲中",//洗衣状态
    Button:true,//默认显示按钮
    time: 40 * 1000,//倒计时初值
    timeData: {},//倒计时数据
    RunningMark:false,//是否显示提交表单
    MotoSpeed:0,//洗衣机转速数值
    Zhuansu:"暂停",//转速显示
    WashingTime: 0,//洗衣时间数据
    //Led: false,//测试用led
    showTime:false,//是否显示洗衣时间
    columns: [//表单内容
      // 第一列
      {
        values: ['二十分钟', '三十分钟', '四十分钟', '五十分钟', '六十分钟', '七十分钟', '八十分钟', '九十分钟'],
        defaultIndex: 2
      },
      // 第二列
      {
        values: ['极低', '较低', '中等', '较高', '极高'],
        defaultIndex: 1
      }
    ]
   
  },
  onOclockChange(e) {
    this.setData({
      timeData: e.detail,
    });
  },
 
  onConfirm(event) {
    var that = this;
    const { picker, value, index } = event.detail;
    Toast(`当前值：${value}, 当前索引：${index}`);
    dataFromTime='+1'+(index[0]+2)+'0'+(index[1]+1)+'*';
    //this.setData({showTime:true})//显示洗衣时间
    this.setData({RunningMark:false})//隐藏提交表单
    //this.setData({RunningSt:"运行中"})//运行状态更新
    //dataFromTime=JSON.stringify(index);
    console.log(dataFromTime);
    that.data.client.publish(mpPubTopic, dataFromTime, function (err) {
      if (!err) {
        console.log("操作成功");
        console.log(dataFromTime);
        wx.showToast({
          title: "操作成功",
          icon: "success",
          mask: true,
        });
      }
    });

   
  },

  onCancel() {
    Toast('取消');
    this.setData({Button:true,RunningMark:false});
  },
  onNoticeBar(){
    var that=this;
      this.setData({NoticeBar:false});
      that.data.client.publish(mpPubTopic, "666666", function (err) {
        if (!err) {
          console.log("取衣成功");
       
          wx.showToast({
            title: "取衣成功",
            icon: "success",
            mask: true,
          });
        }
      });  
  },
  onNoticeBarWarning(){
    this.setData({NoticeBarWarning:false});
},
onButton(){
  this.setData({Button:false,RunningMark:true});

},
  onShow() {
    var that = this;
    wx.showToast({
      title: "连接服务器....",
      icon: "loading",
      duration: 10000,
      mask: true,
    });
    let second = 10;
    var toastTimer = setInterval(() => {
      second--;
      if (second) {
        wx.showToast({
          title: `连接服务器...${second}`,
          icon: "loading",
          duration: 1000,
          mask: true,
        });
      } else {
        clearInterval(toastTimer);
        wx.showToast({
          title: "连接失败",
          icon: "error",
          mask: true,
        });
      }
    }, 1000);
    that.setData({
      client: connect(mqttUrl)
    })

    that.data.client.on("connect", function () {
      console.log("成功连接mqtt服务器！");
      clearInterval(toastTimer);
      wx.showToast({
        title: "连接成功",
        icon: "success",
        mask: true,
      });
      // 一秒后订阅主题
      setTimeout(() => {
        that.data.client.subscribe(mpSubTopic, function (err) {
          if (!err) {
            console.log("成功订阅设备上行数据Topic!");
            wx.showToast({
              title: "订阅成功",
              icon: "success",
              mask: true,
            });
          }
        });
      }, 1000);
    });
    that.data.client.on("message", function (topic, message) {
      console.log(topic);
      console.log(message);
     
        if(message[1]-0x30==1){
        that.setData({
          RunningSt:"运行中",
          showTime:true,
          NoticeBar:false,//通知栏不显示
          RunningMark:false,//是否显示提交表单
          WashingTime: (message[2]-0x30)*10,
          Button:false,//不显示按钮
          NoticeBarWarning:false,//不显示排水故障
          //MotoSpeed: message[4]-0x30,//洗衣机转速数值
          time: ((message[2]-0x30)*10+5) * 1000,//倒计时初值
        })
        console.log(message[0]);
        if(message[4]-0x30==1){that.setData({Zhuansu:"极低"})};
        if(message[4]-0x30==2){that.setData({Zhuansu:"较低"})};
        if(message[4]-0x30==3){that.setData({Zhuansu:"中等"})};
        if(message[4]-0x30==4){that.setData({Zhuansu:"较高"})};
        if(message[4]-0x30==5){that.setData({Zhuansu:"极高"})};
        
      }
      else if(message[1]-0x30==2){
        that.setData({
          RunningSt:"连接断开",
          ButtonAllow:true,//按钮不可以点击
        })
        console.log(message[0]);
        wx.vibrateLong();	// 2、使手机震动400ms
      }
      else if(message[1]-0x30==3){
        that.setData({
          RunningSt:"待取衣",
          showTime:false,//不显示剩余时间
          NoticeBar:true,//通知栏显示
          Button:true,//显示按钮
          ButtonAllow:true,//按钮可以点击
          NoticeBarWarning:false,//不显示排水故障
          //WashingTime: message[2],
          //MotoSpeed: message[4],//洗衣机转速数值
          //time: message[2] * 1000,//倒计时初值
        })
        if(message[5]-0x30==3){
          that.setData({         
            NoticeBar:false,//通知栏显示
          })
        };
        console.log(message[0]);
        wx.vibrateLong();	// 2、使手机震动400ms
      }
      else if(message[1]-0x30==4){
        that.setData({
          RunningSt:"排水故障",
          showTime:false,
          RunningMark:false,//是否显示提交表单
          NoticeBarWarning:true,//显示排水故障
          Button:false,//不显示按钮
          //WashingTime: message[2],
          //MotoSpeed: message[4],//洗衣机转速数值
          //time: message[2] * 1000,//倒计时初值
        })
        console.log(message[0]);
      }
      else if(message[1]-0x30==5){
        that.setData({
          RunningSt:"加水故障",
          showTime:false,
          RunningMark:false,//是否显示提交表单
          NoticeBarWarning:true,//显示排水故障
          Button:false,//不显示按钮
          //WashingTime: message[2],
          //MotoSpeed: message[4],//洗衣机转速数值
          //time: message[2] * 1000,//倒计时初值
        })
        console.log(message[0]);
      }
      else if(message[1]-0x30==6){
        that.setData({
          RunningSt:"空闲中",
          showTime:false,//不显示剩余时间
          NoticeBar:false,//通知栏显示
          Button:true,//显示按钮
          ButtonAllow:false,//按钮可以点击
          NoticeBarWarning:false,//不显示排水故障
          //WashingTime: message[2],
          //MotoSpeed: message[4],//洗衣机转速数值
          //time: message[2] * 1000,//倒计时初值
        })
       
        wx.vibrateLong();	// 2、使手机震动400ms
      }
      
      
    })

   
    
  }
})
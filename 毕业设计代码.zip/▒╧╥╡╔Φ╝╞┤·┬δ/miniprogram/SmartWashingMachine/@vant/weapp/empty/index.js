import { VantComponent } from '../common/component';
VantComponent({
  props: {
    description: String,
    image: {
      type: String,
      value: 'default',
    },
  },
});
